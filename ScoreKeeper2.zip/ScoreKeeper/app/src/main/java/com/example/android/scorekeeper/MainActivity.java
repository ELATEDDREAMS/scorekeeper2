package com.example.android.scorekeeper;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

/**
 * This app displays the score of a football game.
 */
public class MainActivity extends AppCompatActivity {
    int score=0;
    int score2=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * This method is called when the Reset button is clicked.
     */
    public void submitReset(View view) {
        displayScore (score=score-score);
        displayscore2(score2=score2-score2);

    }

    /**
     * This method is called when the Eagle's Touchdown button is clicked.
     */
    public void incrementsixpoints(View view) {
        score= score+6;
        displayScore(score);

    }

    /**
     * This method is called when the Cowboy's Touchdown button is clicked.
     */
    public void incrementsixpoints2(View view) {
        score2=score2+6;
        displayscore2(score2);

    }

    /**
     * This method is called when the Eagle's Field Goal button is clicked.
     */
    public void incrementfieldgoal(View view) {
        score=score+3;
        displayScore(score);

    }

    /**
     * This method is called when the Cowboy's Field Goal button is clicked.
     */
    public void incrementfieldgoal2(View view) {
        score2=score2+3;
        displayscore2(score2);

    }

    /**
     * This method is called when the Eagle's Safety button is clicked.
     */
    public void incrementsafety(View view) {
        score=score+2;
        displayScore(score);

    }

    /**
     * This method is called when the Cowboy's Safety button is clicked.
     */
    public void incrementsafety2(View view) {
        score2=score2+2;
        displayscore2(score2);

    }

    /**
     * This method is called when the Eagle's 1 Point Conversion button is clicked.
     */
    public void incrementonepointconversion(View view) {
        score=score+1;
        displayScore(score);

    }

    /**
     * This method is called when the Cowboy's 1 Point Conversion button is clicked.
     */
    public void incrementonepointconversion2(View view) {
        score2=score2+1;
        displayscore2(score2);

    }

    /**
     * This method is called when the Eagle's 2 Point Conversion button is clicked.
     */
    public void incrementtwopointconversion(View view) {
        score=score+2;
        displayScore(score);

    }

    /**
     * This method is called when the Cowboy's 2 Point Conversion button is clicked.
     */
    public void incrementtwopointconversion2(View view) {
        score2=score2+2;
        displayscore2(score2);

    }
    /**
     * This method displays the given quantity value on the screen.
     */
    private void displayScore(int number) {
        TextView total2 = (TextView) findViewById(R.id.total2);
        total2.setText(""+number);
    }

    /**
     * This method displays the given quantity value on the screen.
     */
    private void displayscore2(int number) {
        TextView total3 = (TextView) findViewById(R.id.total3);
        total3.setText(""+number);
    }
}